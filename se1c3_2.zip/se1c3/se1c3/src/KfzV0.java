public class KfzV0 {
    public int sitze;
    public int tankInhalt;
    public float verbrauch;

    public float reichweite() {
        return (tankInhalt / verbrauch) * 100;
    }

    public float spritVerbrauch(int km) {
        return (km / 100.0f) * verbrauch;
    }
}