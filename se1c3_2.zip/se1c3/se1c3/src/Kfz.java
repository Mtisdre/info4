public class Kfz {
    private int sitze;
    private int tankInhalt;
    private float verbrauch;

    public Kfz(int sitze, int tankInhalt, float verbrauch) {
        this.sitze = sitze;
        this.tankInhalt = tankInhalt;
        this.verbrauch = verbrauch;
    }

    public float reichweite() {
        return tankInhalt / verbrauch * 100;
    }

    public float spritVerbrauch(int km) {
        return verbrauch / 100 * km;
    }
}