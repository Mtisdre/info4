public class LkwDemo {
    public static void main(String[] args) {
        Kfz sportWagen = new Kfz(2, 45, 11f);
        Lkw magirus = new Lkw(2, 45, 11f, 20, true);

        System.out.println("Verbrauch von Sportwagen auf 252 km: " + sportWagen.spritVerbrauch(252) + " Liter");
        System.out.println("Verbrauch von Magirus (Lkw) auf 252 km: " + magirus.spritVerbrauch(252) + " Liter");
    }
}