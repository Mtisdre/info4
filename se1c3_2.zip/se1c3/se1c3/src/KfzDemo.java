public class KfzDemo {
    public static void main(String[] args) {
        KfzV0 minivan = new KfzV0();
        minivan.sitze = 6;
        minivan.tankInhalt = 70;
        minivan.verbrauch = 14;

        float reichweite = (minivan.tankInhalt / minivan.verbrauch) * 100;
        System.out.println("Mögliche Reichweite des Minivans: " + reichweite + " km");
    }
}